from main import simulate_variable_impact

simulate_variable_impact('acceleration', 0.04, 1.0)
