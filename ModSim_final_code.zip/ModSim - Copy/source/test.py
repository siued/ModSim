import numpy as np

print(np.random.randint(2))